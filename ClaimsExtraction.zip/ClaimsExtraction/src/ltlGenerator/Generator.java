package ltlGenerator;

import java.util.Arrays;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;


import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;


public class Generator {
	public static void main(String   argv[]) throws IOException{
		
        /**************************************************************************************/
        /* This part is part of future work to enable reading dataset provided as excel file  */
        /**************************************************************************************/
		
		
		
		
	      try {	
	    	  
	          long startTime = System.currentTimeMillis();
	          String xmlPath = "src/ltlGenerator";
	          File inputFile = new File(xmlPath+"\\bankSystem.xml"); //read a UML Model as .xml file
	         
	         
	         // initiate parser 
	         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance(); 
	         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	         Document doc = dBuilder.parse(inputFile);
	         doc.getDocumentElement().normalize();
	         	         
	         char[] operators = new char[] { '&', '|', ' '}; // needed for tokenize a string based on these seperators
	         

	    /**************************************************************************************/
	    /*                          Read Proxies from Excel Sheet                             */
	    /**************************************************************************************/
	         
	        HashMap<String, List<String>> proxiesMap = new HashMap<String, List<String>>();
	        
	        File myExcelBook=new File("ProxyOfBankSystem.xlsx");

	 		FileInputStream data=new FileInputStream(myExcelBook); 
	 		
	 		XSSFWorkbook wb= new XSSFWorkbook(data);
	 		
	 	    // Return first sheet from the XLSX workbook
	 		XSSFSheet sheet= wb.getSheetAt(0);  
	 		
	 	    // Create a DataFormatter to format and get each cell's value as String
	        DataFormatter dataFormatter = new DataFormatter();
	        
	 	    // Get iterator to all the rows in current sheet 
	 		Iterator<Row> rowIterator = sheet.iterator();
	 		
	 	    // Traversing over each row of XLSX file 
	 		while (rowIterator.hasNext()) 
	 		{ 
	 			Row row = rowIterator.next();
	 			
	 		    // Now let's iterate over the columns of the current row
	            Iterator<Cell> cellIterator = row.cellIterator();
	            List<String> proxies=new ArrayList<String>();
	         if(row.getRowNum()!=0) 
	         {
	            while (cellIterator.hasNext()) {
	            	
	                Cell cell = cellIterator.next();
	                if (cell == null || cell.getCellType() == Cell.CELL_TYPE_BLANK) {
		     	          // Nothing in the cell in this row, skip it
		     	       }
	                else if(cell.getColumnIndex()!=0)
	            	{
	            		String cellValue = dataFormatter.formatCellValue(cell);
	            		proxies.add(cellValue);
	            	}
	                
	            }
	            
	            Cell firstCell=row.getCell(0);
	            String prot=dataFormatter.formatCellValue(firstCell);
	            proxiesMap.put(prot, proxies);
	         }
	            
	            
	            
	            
	 		}


	 
		    /**************************************************************************************/
		    /*           Map sensitive decisions with their corresponding classifiers             */
		    /**************************************************************************************/
	 		
	 		
	         List<String> basedClassifierFortoBeAnalyzedStateMachines = new ArrayList<String>();    // to store the identifier of the base-class of each <individualFairness>-annotated state machine. 
	         NodeList basedClassifierList = doc.getElementsByTagName("UMLFairness:indvidualFairness"); // retrieve all the <individualFairness>-annotated elements
	         HashMap<String, List<String>> mapSensitiveClassifier = new HashMap<String, List<String>>();
	         
	         // Now we iterate over all retrieved behavior classifiers 
	         for (int temp = 0; temp < basedClassifierList.getLength(); temp++) {

	     		Node basedClassifierNode = basedClassifierList.item(temp);
	     				
	     		
	     		if (basedClassifierNode.getNodeType() == Node.ELEMENT_NODE) {

	    			Element eElement = (Element) basedClassifierNode;
                     
	    			String classifierID=eElement.getAttribute("base_BehavioredClassifier"); // return the id of the bahavior classifier
	    			
                    
	    			basedClassifierFortoBeAnalyzedStateMachines.add(classifierID); // add it to the list
	    			
                    String sens=eElement.getElementsByTagName("sensitiveDecisions").item(0).getTextContent(); //return all the specified senstive decisions
                    
                    String answer = sens.substring(sens.indexOf("(")+1,sens.indexOf(")")); // manually remove or add the last (+1) based on the type of the sensitive decision

                    String [] values = answer.split(",");

                    List<String> sensitiveList = new ArrayList<String>();

                    // String[] values = sens.split(",");

	    			//Pattern pattern = Pattern.compile("\\w+");


                    for(String v:values)
                    {
                    	sensitiveList.add(v);
                    }
	    		    /*Matcher matcher = pattern.matcher(sens);
	    			while (matcher.find()) {
	    				sensitiveList.add(matcher.group());
	    			}*/
	    			
	    			
	   	            mapSensitiveClassifier.put(classifierID,sensitiveList); // map classifier id with it is corresponding sensitive decision.
                    
	    			
	    		}
	    	}
	         

	         /**************************************************************************************/
			 /*           Map the guards with their corresponding classifiers                      */
		    /**************************************************************************************/
	         
	         
	         NodeList packages = doc.getElementsByTagName("packagedElement");// return all element of type packagedElement
	         HashMap<String, List<String>> classifiersGaurds = new HashMap<String, List<String>>();
	         HashMap<String, List<String>> classifiersAttributes = new HashMap<String, List<String>>();
	         HashMap<String, String> mapClassIDName = new HashMap<String, String>();


	         //Now iterate over the packages
	         for (int temp = 0; temp < packages.getLength(); temp++) {

		     		Node packageNode = packages.item(temp); // get a package element node
		     				
		     		
		     		if (packageNode.getNodeType() == Node.ELEMENT_NODE) {

		    			Element eElement = (Element) packageNode; // Caste package node to element
	                     
		    			//Check if package element of type UML class
		    			if(eElement.getAttribute("xmi:type").equals("uml:Class"))
		    			{
			    			String classifierID=eElement.getAttribute("classifierBehavior");// return the classifierBehavior id of the class
			    			String cID=eElement.getAttribute("xmi:id");
			    			String cName=eElement.getAttribute("name");
			    			mapClassIDName.put(cID, cName);
			    			
			    			 for(Map.Entry item:mapSensitiveClassifier.entrySet())
			 	            {
			 	                 String id=(String)item.getKey();
			 		        	 if(id.equals(classifierID))
			 		        	 {
			 		        		List<String> store= new ArrayList<String>();
			 		        		store=mapSensitiveClassifier.get(id);
			 		        		mapSensitiveClassifier.remove(id);
			 		        		mapSensitiveClassifier.put(eElement.getAttribute("name"), store);
			 		        	 }
			 	            }
			    			
			    			// check if the classifierBehavior id is already stored in the map of classifierBehavior ids and their sensitive decisions
			    			if(basedClassifierFortoBeAnalyzedStateMachines.contains(classifierID))
			    			{
			    				 NodeList gList = eElement.getElementsByTagName("ownedRule"); // return the classifier guards
			    				 List<String> guardList = new ArrayList<String>();
			    				 
			    				 // iterate over the returned guards
			    		         for (int i = 0; i < gList.getLength(); i++) {

			    			     		Node gNode = gList.item(i);
			    			     				
			    			     		
			    			     		if (gNode.getNodeType() == Node.ELEMENT_NODE) {

			    			    			Element g = (Element) gNode;
			    		                     
			    			    			String guard=g.getAttribute("name");
			    			    			
			    			    			// Skip overlooking for else guards 
			    			    			if (guard.equals("else")!=true)
			    			    			{
			    			    				String delim = new String(operators);    
			    			    			    StringTokenizer st = new StringTokenizer(guard, delim); // remove special characters from the gaurd
			    			    			    
			    			    			    while (st.hasMoreTokens()) {
			    			    			    	guardList.add(st.nextToken()); // add the guard to the list of guards
			    			    			    }
			    			    			      
			    			    			}
			    			    			
			    			    		}
			    			     					    			     		
			    			    	}
			    		         
			    		     
			    		         classifiersGaurds.put(classifierID, guardList); //  map each behavior classifier with its corresponding gaurds
			    			}
			    			
			    			
			    		 /**************************************************************************************/
			   			 /*           Map the attributes with their corresponding classifiers                 */
			   		    /**************************************************************************************/
			    			
		    				 NodeList attList = eElement.getElementsByTagName("ownedAttribute"); // return all attributes of the behavior classifier
		    				 List<String> attributesList = new ArrayList<String>();
		    				 
		    				 // iterate over all the attributes
		    				 for(int iterator=0; iterator<attList.getLength();iterator++)
		    				 {
		    					 Node atNode = attList.item(iterator);
		    					 
		    					 if(atNode.getNodeType()==Node.ELEMENT_NODE)
		    					 {
		    						 Element att= (Element) atNode;
		    						 
		    						 // look only for those attribute that has the type UML Property
		    						 if(att.getAttribute("xmi:type").equals("uml:Property"))
		    						 {
		    							 attributesList.add(att.getAttribute("name")); // return the name of the attribute and stor it to the list
		    						 }
		    						 
		    					 }
		    					 
		    					 
		    				 }
		    				 
		    		

		    		        classifiersAttributes.put(eElement.getAttribute("name"), attributesList); // map the classifiers with their attributes.
		    				}
		    					}
		    			
		    			
		    			
		    			
		    		}
		    	
	         
	         /**************************************************************************************/
   			 /*           Map the attributes with their corresponding classifiers                 */
   		    /**************************************************************************************/
        	         
	         
	         NodeList pList = doc.getElementsByTagName("UMLFairness:critical");
	         HashMap<String, List<String>> mapClassCriticalData = new HashMap<String, List<String>>();

	         
	         
	         for (int temp = 0; temp < pList.getLength(); temp++) {

	     		Node pNode = pList.item(temp);
	     				
	     		
	     		if (pNode.getNodeType() == Node.ELEMENT_NODE) {

   	   	            List<String> protectedList = new ArrayList<String>();

	    			Element eElement = (Element) pNode;
	    			
	    			String basedStructureClass=eElement.getAttribute("base_StructuredClassifier");
                     
	    			String prot=eElement.getElementsByTagName("protectedData").item(0).getTextContent();
	    			
	    			Pattern pattern = Pattern.compile("\\w+");
	    			Matcher matcher = pattern.matcher(prot);
	    			while (matcher.find()) {
	    				protectedList.add(matcher.group());
	    			}
	    			
	    			
	    			String name=mapClassIDName.get(basedStructureClass);
	    			mapClassCriticalData.put(name, protectedList);
	    			
	    			
	    		}
	    	}
	         
             
             


//-------------------------------------------------------------------------------------------------------

	        
/*	            HashMap<String, List<String>> dataExtractionMapping = new HashMap<String, List<String>>();
		        List<String> columnsNames = new ArrayList<String>();

	        	Row firstRow = sheet.getRow(0);
	        	
	        	for(Cell cell:firstRow)
	        	{
	        		columnsNames.add(cell.getStringCellValue());
	        	}
	
		        for (String colName: columnsNames) {
		 	       
			        int colNo = -1;
		        	String columnWanted = colName;
		        	List<String> cells = new ArrayList<String>();
		        	XSSFRow fRow = sheet.getRow(0);
		        	
		        	for(Cell c:fRow){
		        		
		        		if (c.getStringCellValue().equals(columnWanted)){
		        			colNo = c.getColumnIndex();
		        		}
		        	}
		        	
		        	 if (colNo != -1){
		        	   for (Row r : sheet) {
			     	       Cell c = r.getCell(colNo);
			     	       if (c == null || c.getCellType() == Cell.CELL_TYPE_BLANK) {
			     	          // Nothing in the cell in this row, skip it
			     	       } else {
			     	    	  
			     	    	  if (r.getRowNum()!=0)
			     	    	  {
			     	    		 if(c.getCellType()==Cell.CELL_TYPE_BOOLEAN)
			     	    		 {
			     	    			cells.add(Boolean.toString(c.getBooleanCellValue()));
			     	    		 }
			     	    		 
			     	    		if(c.getCellType()==Cell.CELL_TYPE_STRING)
			     	    		 {
			     	    			cells.add(c.getStringCellValue());
			     	    		 }
			     	    		
			     	    		if(c.getCellType()==Cell.CELL_TYPE_NUMERIC)
			     	    		 {
			     	    			cells.add(Double.toString(c.getNumericCellValue()));
			     	    		 }
			     	             
			     	    	  }
			     	    	 
			     	       }
			     	       
			     	       
			     	    }
		        	  
		        	 }
		        	 
		        	 
		       dataExtractionMapping.put(columnWanted, cells); // map protected data to their columns on the excell sheet
		  }*/
	        		      
//	 ---------------------------------------------------------------- End  Data Extractions from the excel sheet-----------------------         
	         
	         
	         HashMap<String, List<String>> explanatory = new HashMap<String, List<String>>();
        	 List<String> sensitives=new ArrayList<String>();

	         List<String> explanatoryList = new ArrayList<String>();
	         NodeList exList = doc.getElementsByTagName("UMLFairness:indvidualFairness");
	         
	         
	         for (int temp = 0; temp < exList.getLength(); temp++) {

	     		Node exNode = exList.item(temp);
	     				
	     		
	     		if (exNode.getNodeType() == Node.ELEMENT_NODE) {

	    			Element eElement = (Element) exNode;
                     
	    			NodeList exlistNode = eElement.getElementsByTagName("explanatoryData");
	    			
	    			for (int idx=0;idx<exlistNode.getLength();idx++)
	    			{
	    				Node explanatoryNode=exlistNode.item(idx);
	    				if(explanatoryNode.getNodeType()==Node.ELEMENT_NODE)
	    				{
	    					Element exElement=(Element) explanatoryNode;
	    					String sens=exElement.getTextContent();
	    					Pattern pattern = Pattern.compile("(\\(.*?)\\)\\)");
	    	    			Matcher matcher = pattern.matcher(sens);
	    	    			while (matcher.find()) {
	    	    				explanatoryList.add(matcher.group());
	    	    			}
	    					
	    				}
	    			}
	    		
	    			

	    		}
	    	}
	         
	         
	         
	         for (String ex: explanatoryList) {
		         
	        	 List<String> arraylist=new ArrayList<String>();

    	         List<String> l = new ArrayList<String>();
    	         Pattern pattern = Pattern.compile("\\w+");
	    			Matcher matcher = pattern.matcher(ex);
	    			while (matcher.find()) {
	    				arraylist.add(matcher.group());
	    			}
	    				        	 

	        	 String firstSensitive=arraylist.get(arraylist.size() - 1); 
        		 sensitives.add(firstSensitive);
        		 


	        	 arraylist.remove(arraylist.size() - 1);
	        	 
	        	 for(String element:arraylist)
	        	 {
	        		 

	    	         l.add(element);
  
	        	 }
	        	 
	        	 explanatory.put(firstSensitive, l);/// map sensitive with explanatory

	         }
	         
//---------------------------------------------------------------- End explanatory data with respect to sensitive decisions Extractions----------------------- 
	         
      

	        NodeList modelAttributes = doc.getElementsByTagName("ownedAttribute");

	        List<String> derivedAttributes = new ArrayList<String>();

 			
 			for (int var = 0; var < modelAttributes.getLength(); var++) {


 	     		Node attNode = modelAttributes.item(var);
 	     				
 	     		
 	     		if (attNode.getNodeType() == Node.ELEMENT_NODE) {

 	    			Element att = (Element) attNode;
                    
 	    			if ((att.getAttribute("isDerived")).equals("true"))
 	    			{
 	    				String attName=att.getAttribute("name");
 	    				
 	    			     derivedAttributes.add(attName);
 	    			}
 	    		
 	    			}
 			}
 	    			
 /*  ----------------------------------------------Derived Attributes---------------------------*/
	       //  HashMap<String, List<String>> mapClaimsWithSen = new HashMap<String, List<String>>();

	         HashMap<List<String>, String> mapClaimsWithSen = new HashMap<List<String>, String>();

	         int claimNum=0;
	         for (Map.Entry behaveClass:mapSensitiveClassifier.entrySet())
	         {
	        	 String behaveClassName=(String)behaveClass.getKey();
	        	 List<String> contenet=new ArrayList<String>();
	        	 contenet=mapSensitiveClassifier.get(behaveClassName);
	        	 
	        	 for(String s:contenet)
	        	 {
      	    		List<String> usedCondition = new ArrayList<String>();

	        		 for(Map.Entry cl:classifiersGaurds.entrySet())
	 	            {
	 	                 String k=(String)cl.getKey();

	 		        	 
	 		        	for (String g:classifiersGaurds.get(k))
	 	        	    {

	 		        		       String co=g;
	 		    	        	   co = co.replaceAll("false", "");

	 		    	        	   co = co.replaceAll("true", "");
	 		    	        	    
	 		    	        	    String[] items = co.replaceAll("[^a-zA-Z ]", "").split("\\s+");

	 		    	        	    boolean protectedFlag=false;
	 		    	        	    boolean explanatoryFlag=false;
	 		    	        	    boolean derivedFlag=false;
	 		    	        	   
	 		    	        	    for (String item:items)
	 		    	        	    {


	 		    	        	    	for(Map.Entry prot:proxiesMap.entrySet())
	 		    	        	    	{
	 			    	        	    	

	 		    	        	    		String protec=(String)prot.getKey();
	 		    	        	    		
	 		    	        	    		for(String prox:proxiesMap.get(protec))
	 		    	        	    		{

	 		    	        	    			if(protec.equals(item)==true || prox.equals(item)==true)
	 		    	        	    			{
	 		    	        	    				protectedFlag=true; //the item is a protected or a proxy for protected characteristic 
	 		    	        	    			}
	 		    	        	    			
	 		    	        	    		}
	 		    	        	    	}
	 		    	        	    	
	 		    	        	    
	 		    	        	    	if (protectedFlag==true)
	 		    	        	    	{
	 		    	        	    	     if(explanatory.containsKey(s))
	 		    	        	    	    {
	 		    	        	    	    	for (String explanForS:explanatory.get(s))
		 		    	        	        	{
		 		    	        	    	    	if(explanForS.equals(item)==true)
		 		    		    	            	{
		 		    		        	    		    explanatoryFlag=true;// avoid looking for explanatory
		 		    	        	    			
		 		    		    	        	    }
		 		    	        	    	
		 		    	        	    	}
	 		    	        	    	}
	 		    	        	    	}
	 		    	        	    	
	 		    	        	    	
	 		    	        	    	if(derivedAttributes.contains(item))
	 		    	        	    	{
	 	    		        	    		derivedFlag=true;///// avoid looking for derived attributes
	 		    	        	    	}
	 		    	        	    	


	 		    	        	    	if (protectedFlag==true && explanatoryFlag==false && derivedFlag==false)
	 		    	        	    	{

 	        		         	    		List<String> batch = new ArrayList<String>();

	 		    	        	    		for (Map.Entry classifier:classifiersAttributes.entrySet())
	 		    	        		         {
	 		    	        		        	 String className=(String)classifier.getKey();

	 		    	        		        	 List<String> attributes=new ArrayList<String>();
	 		    	        		        	 attributes=classifiersAttributes.get(className);
	 		    	        		        	
	 		    	        		        	
	 		    	        		        		    if(attributes.contains(item))
	 		    	        		        		    {
	 		    	        		        		    	if(s.endsWith("()")!=true)
	 		    	        		        		    	{

	 		    	        		        		    		batch.add("ltl claim{("+className+"_"+g+")-> <>("+className+"_"+s+"==true)}");
		 		    	        		        		    	batch.add("ltl claim{!("+className+"_"+g+")-> <>("+className+"_"+s+"==true)}");
		 		    	        		        		    	batch.add("ltl claim{("+className+"_"+g+")-> <>("+className+"_"+s+"==false)}");
		 		    	        		        		    	batch.add("ltl claim{!("+className+"_"+g+")-> <>("+className+"_"+s+"==false)}");
	 		    	        		
	 		    	        		        		    	}
	 		    	        		        		    	else{
	 		    	        		        		    		
	 		    	        		        		    		String output = s.replaceAll("\\([^)]*?\\)", "");
	 		    	        		        		    		
	 		    	        		        		    		batch.add("ltl claim{("+className+"_"+g+")-> <>(event_queues[1]?[call_"+s.replaceAll("\\([^)]*?\\)", "")+"])}");
	 		    	        		        		    		batch.add("ltl claim{!("+className+"_"+g+")-> <>(event_queues[1]?[call_"+s.replaceAll("\\([^)]*?\\)", "")+"])}");
	 		    	        		        		    	}

	 		    	        		        		    }
	 		    	        		        	   
	 		    	        	    		      
	 		    	        		         }
	 		    	        	    		
	 		    	        	    		mapClaimsWithSen.put(batch, s);

	 		    	        	    		
	 		    	        	    	}
	 		    	        	    	
	 		    	        	    	
	 		    	        	   
	 		    	        	       }
	 		        		 
	 	        	    	}
	 	            	
	 	            }
	        	 }
	         }
	         
             
	         


	         FileWriter writerProtected = new FileWriter("Report.txt"); 
             if(mapClassCriticalData.size()>0)
        	 {writerProtected.write("The model has "+mapClassCriticalData.size()+ " critical class." + System.lineSeparator());
        	  
        	 }
             else
        	 {
        		 writerProtected.write("The model has "+mapClassCriticalData.size()+ " critical classes." + System.lineSeparator());
        	 }
        	 
             int count=0;
             for (Map.Entry iter:mapClassCriticalData.entrySet())
	         {
            	 count++;
	        	 String cName=(String)iter.getKey();
	        	 List<String> protectedList=new ArrayList<String>();
	        	 protectedList=mapClassCriticalData.get(cName);
	        	 
	        	 writerProtected.write("---------------------------------------------------"+System.lineSeparator());
	        	 writerProtected.write(count+". "+"Class name: "+cName+ System.lineSeparator());
	        	 writerProtected.write("---------------------------------------------------"+System.lineSeparator());

	        	 writerProtected.write(System.lineSeparator());
	        	 writerProtected.write("\t"+"Protected characteristics: ");
	        	 
	    
	        	 for(String p:protectedList)
	        	 {
	        		 int pos =protectedList.indexOf(p); 

	        		 if(pos==0)
	        		  {
	        			 writerProtected.write(p);
	        		  }
	        		 else
	        		 {
	        			 writerProtected.write(", "+p);
	        		 }
	        	 }
	        	 
	        	 writerProtected.write("."+ System.lineSeparator());
	        	 
	        	 List<String> listOfSensi=new ArrayList<String>();

	        	 listOfSensi=mapSensitiveClassifier.get(cName);
	        	 
	        	 writerProtected.write(System.lineSeparator());
	        	 writerProtected.write("\t"+"Sensitive decisions: ");

	        	 for(String dec:listOfSensi)
	        	 {
	        		 int ix =listOfSensi.indexOf(dec); 

	        		 if(ix==0)
	        		  {
	        			 writerProtected.write(dec);
	        		  }
	        		 else
	        		 {
	        			 writerProtected.write(", "+dec);
	        		 }
	        		 
	        	 }
	        	 
	        	 writerProtected.write("."+ System.lineSeparator());
	        	 
	        	 int y=0;

	        	 for(String decision:listOfSensi)
	        	 {
	        		 writerProtected.write(System.lineSeparator());
	        		 writerProtected.write(System.lineSeparator());
		        	 
		        	 
		        	 for (Map.Entry x:mapClaimsWithSen.entrySet())
			         {
		        		 
		        		List<String> batch=new ArrayList<String>();
		        		batch=(List<String>)x.getKey();
			        	if(x.getValue().equals(decision)) {
			        		 y++;
			        		 
			        		 writerProtected.write("\t"+"-----------------------------------------------------------------------------"+System.lineSeparator());
				        	 writerProtected.write("\t"+"batch "+y+": "+"ltl claims with respect to "+ decision+ "."+System.lineSeparator());
				        	 writerProtected.write("\t"+"-----------------------------------------------------------------------------"+System.lineSeparator());

				        	 
				        	 for(String claim:batch)
				        	 {
				        		 writerProtected.write(System.lineSeparator());
					        	 writerProtected.write("\t"+"\t"+claim+System.lineSeparator());
				        		  
				        		 
				        	 }
			        		 writerProtected.write(System.lineSeparator());

			        	}
       
			        	    
			         }
		        	 
		        	 
		        	 
		        	 
		        	 
	        	 }
	        	 
		        	 

	        	 
	         }
	          long endTime = System.currentTimeMillis();
	          long output = endTime - startTime;
	         writerProtected.close();
             System.out.println("Completed Successfully!");
             System.out.println("Time[ms]:"+output);
	         
//---------------------------------------------------------------- End usedGuards conditions Extractions----------------------- 
	         
	         

	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	   }
	}


